<?php
/*
 * Copyright © 2021, Oracle and/or its affiliates. All rights reserved.
 *
 * Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl.
 */

namespace Bronto\M2\Impl\Core;

class Urls implements \Bronto\M2\Core\Store\UrlManagerInterface
{
    protected $_frontendUrl;

    /**
     * @param \Magento\Framework\Url $frontendUrl
     */
    public function __construct(
        \Magento\Framework\Url $frontendUrl
    ) {
        $this->_frontendUrl = $frontendUrl;
    }

    /**
     * @see parent
     */
    public function getFrontendUrl($store, $path, $params = [])
    {
        return $this->_frontendUrl->setScope($store)->getUrl($path, $params);
    }
}
