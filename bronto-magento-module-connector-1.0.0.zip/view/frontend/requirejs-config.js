var config = {
    map: {
        '*': {
            connectorClient: 'Bronto_Connector/js/client',
            fiddleAbstract: 'Bronto_Connector/js/fiddleAbstract',
            brontoStorage: 'Bronto_Connector/js/brontoStorage'
        }
    }
}